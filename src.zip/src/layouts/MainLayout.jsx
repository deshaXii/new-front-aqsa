import React from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import ThemeToggle from "../components/ThemeToggle.jsx";
import AuthGuard from "../context/authGuard.jsx";

const MainLayout = () => {
  const location = useLocation();

  const menu = [
    { path: "/repairs", label: "الصيانات" },
    { path: "/technicians", label: "الفنيين" },
    { path: "/invoices", label: "الفواتير" },
    { path: "/backup", label: "النسخ الاحتياطي" },
  ];

  return (
    <AuthGuard>
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white">
        {/* Header */}
        <header className="flex items-center justify-between px-4 py-3 shadow bg-white dark:bg-gray-800">
          <h1 className="text-lg font-bold">نظام صيانة الأجهزة</h1>
          <ThemeToggle />
        </header>

        {/* Navigation */}
        <nav className="flex gap-2 overflow-auto px-4 py-2 bg-gray-100 dark:bg-gray-700 text-sm">
          {menu.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`px-3 py-1 rounded ${
                location.pathname.startsWith(item.path)
                  ? "bg-blue-600 text-white"
                  : "bg-gray-300 dark:bg-gray-600 hover:bg-gray-400"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Page Content */}
        <main className="flex-1 p-4">
          <Outlet />
        </main>
      </div>
    </AuthGuard>
  );
};

export default MainLayout;
