import { create } from "zustand";

const useAuthStore = create((set) => ({
  token: null,
  user: null,

  login: (token, user) => {
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(user));
    localStorage.setItem("loginTime", Date.now());
    set({ token, user });
  },

  logout: () => {
    localStorage.clear();
    set({ token: null, user: null });
  },
}));

export default useAuthStore;
