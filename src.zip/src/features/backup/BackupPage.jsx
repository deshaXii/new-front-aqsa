import React, { useEffect, useState } from "react";
import axios from "axios";
import useAuthStore from "../auth/authStore.js";
import Notification from "../../components/Notification.jsx";
import Button from "../../components/Button.jsx";

const BackupPage = () => {
  const { token } = useAuthStore();
  const [stats, setStats] = useState({
    repairs: 0,
    technicians: 0,
    dbSize: 0,
    warning: false,
  });
  const [message, setMessage] = useState("");

  const fetchStats = async () => {
    try {
      const { data } = await axios.get(
        "http://localhost:5000/api/backup/stats",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setStats(data);
    } catch (err) {
      setMessage("فشل تحميل إحصائيات النظام");
    }
  };

  const exportBackup = async () => {
    try {
      window.open("http://localhost:5000/api/backup/export", "_blank");
    } catch (err) {
      setMessage("فشل في التصدير");
    }
  };

  const importBackup = () => {
    alert("قريبًا: سيتم دعم استيراد النسخة الاحتياطية من ملف");
  };

  const clearAll = () => {
    if (window.confirm("هل أنت متأكد من مسح كل البيانات؟")) {
      alert("سيتم تنفيذ هذه العملية لاحقًا");
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-xl font-bold mb-4">
        النسخ الاحتياطي وإحصائيات النظام
      </h2>

      {message && <Notification type="error" message={message} />}

      <div className="bg-white dark:bg-gray-800 p-4 rounded shadow mb-4">
        <p>عدد الصيانات: {stats.repairs}</p>
        <p>عدد الفنيين: {stats.technicians}</p>
        <p>
          حجم قاعدة البيانات: {stats.dbSize} MB{" "}
          {stats.warning && (
            <span className="text-red-600 font-bold">(اقتربت من الحد!)</span>
          )}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Button onClick={exportBackup} variant="primary">
          تصدير نسخة احتياطية
        </Button>
        <Button onClick={importBackup} variant="secondary">
          استيراد نسخة احتياطية
        </Button>
        <Button onClick={clearAll} variant="danger">
          مسح كل البيانات
        </Button>
      </div>
    </div>
  );
};

export default BackupPage;
