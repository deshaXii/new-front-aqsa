import React from "react";
import { Routes, Route } from "react-router-dom";
import BackupPage from "./BackupPage.jsx";

const BackupRoutes = () => {
  return (
    <Routes>
      <Route index element={<BackupPage />} />
    </Routes>
  );
};

export default BackupRoutes;
