import React, { useEffect, useState } from "react";
import axios from "axios";
import useAuthStore from "../auth/authStore.js";
import Notification from "../../components/Notification.jsx";

const InvoicesPage = () => {
  const [invoices, setInvoices] = useState([]);
  const [error, setError] = useState("");
  const { token } = useAuthStore();

  const fetchInvoices = async () => {
    try {
      const { data } = await axios.get("http://localhost:5000/api/invoices", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setInvoices(data);
    } catch (err) {
      setError("فشل تحميل الفواتير");
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  const formatDate = (date) => new Date(date).toLocaleDateString("ar-EG");

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h2 className="text-xl font-bold mb-4">الفواتير والإحصائيات</h2>
      {error && <Notification type="error" message={error} />}

      <div className="overflow-auto">
        <table className="min-w-full bg-white dark:bg-gray-800 border text-sm">
          <thead className="bg-gray-200 dark:bg-gray-700">
            <tr>
              <th className="p-2 border">التاريخ</th>
              <th className="p-2 border">الفني</th>
              <th className="p-2 border">سعر الإصلاح</th>
              <th className="p-2 border">سعر الجملة</th>
              <th className="p-2 border">ربح المحل</th>
              <th className="p-2 border">ربح الفني</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <tr key={inv._id}>
                <td className="p-2 border">{formatDate(inv.date)}</td>
                <td className="p-2 border">{inv.technician?.name}</td>
                <td className="p-2 border">{inv.totalRepairPrice} ج</td>
                <td className="p-2 border">{inv.totalPartsCost} ج</td>
                <td className="p-2 border">{inv.shopProfit} ج</td>
                <td className="p-2 border">{inv.techProfit} ج</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default InvoicesPage;
