import React from "react";
import { Routes, Route } from "react-router-dom";
import InvoicesPage from "./InvoicesPage.jsx";

const InvoicesRoutes = () => {
  return (
    <Routes>
      <Route index element={<InvoicesPage />} />
    </Routes>
  );
};

export default InvoicesRoutes;
