import React from "react";
import { Routes, Route } from "react-router-dom";
import AuthLayout from "./layouts/AuthLayout.jsx";
import MainLayout from "./layouts/MainLayout.jsx";

import AuthRoutes from "./features/auth/authRoutes.jsx";
import RepairsRoutes from "./features/repairs/repairsRoutes.jsx";
import TechniciansRoutes from "./features/technicians/techniciansRoutes.jsx";
import InvoicesRoutes from "./features/invoices/invoicesRoutes.jsx";
import BackupRoutes from "./features/backup/backupRoutes.jsx";

import HomePage from "./pages/HomePage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";

import useAuthStore from "./features/auth/authStore.js";

const token = localStorage.getItem("token");
const user = localStorage.getItem("user");
if (token && user) {
  useAuthStore.getState().login(token, JSON.parse(user));
}

const App = () => {
  return (
    <Routes>
      {/* صفحات تسجيل الدخول */}
      <Route element={<AuthLayout />}>
        <Route path="/login/*" element={<AuthRoutes />} />
      </Route>

      {/* لوحه التحكم */}
      <Route element={<MainLayout />}>
        <Route index element={<HomePage />} />
        <Route path="/repairs/*" element={<RepairsRoutes />} />
        <Route path="/technicians/*" element={<TechniciansRoutes />} />
        <Route path="/invoices/*" element={<InvoicesRoutes />} />
        <Route path="/backup/*" element={<BackupRoutes />} />
      </Route>

      {/* أي مسار غير معروف */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
};

export default App;
