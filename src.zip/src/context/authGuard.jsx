import React from "react";
import { Navigate } from "react-router-dom";
import useAuthStore from "../features/auth/authStore.js";

const AuthGuard = ({ children }) => {
  const { token } = useAuthStore();
  const loginTime = Number(localStorage.getItem("loginTime"));
  const expired = Date.now() - loginTime > 60 * 60 * 1000;

  if (!token || expired) {
    localStorage.clear();
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default AuthGuard;
