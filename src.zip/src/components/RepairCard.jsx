import React from "react";

const RepairCard = ({ repair }) => {
  const {
    customerName,
    deviceType,
    color,
    issue,
    phone,
    price,
    totalPartsCost,
    profit,
    status,
    parts = [],
    technician,
    recipient,
    createdAt,
  } = repair;

  const translateStatus = (status) => {
    const map = {
      pending: "في الانتظار",
      in_progress: "جاري العمل",
      completed: "مكتمل",
      delivered: "تم التسليم",
      rejected: "مرفوض",
    };
    return map[status] || status;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded shadow p-4 mb-4">
      <h3 className="text-lg font-bold mb-2 text-blue-600">{customerName}</h3>
      <p>
        📱 <strong>الجهاز:</strong> {deviceType} - {color}
      </p>
      <p>
        ⚠️ <strong>العطل:</strong> {issue}
      </p>
      <p>
        📞 <strong>رقم الهاتف:</strong> {phone}
      </p>
      <p>
        🧑‍🔧 <strong>الفني:</strong> {technician?.name || "غير محدد"}
      </p>
      <p>
        📥 <strong>المستلم:</strong> {recipient?.name || "غير محدد"}
      </p>
      <p>
        💰 <strong>السعر:</strong> {price} ج
      </p>
      <p>
        🧩 <strong>سعر القطع:</strong> {totalPartsCost || 0} ج
      </p>
      <p>
        📈 <strong>الربح:</strong> {profit || 0} ج
      </p>
      <p>
        🕒 <strong>الحالة:</strong> {translateStatus(status)}
      </p>
      <p>
        📅 <strong>التاريخ:</strong>{" "}
        {new Date(createdAt).toLocaleDateString("ar-EG")}
      </p>

      {parts.length > 0 && (
        <div className="mt-2">
          <strong>قطع الغيار:</strong>
          <ul className="list-disc list-inside text-sm">
            {parts.map((part, index) => (
              <li key={index}>
                {part.name} - {part.source} ({part.price} ج)
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default RepairCard;
