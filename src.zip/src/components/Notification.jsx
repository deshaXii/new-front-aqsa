import React from "react";

const Notification = ({ type = "info", message }) => {
  const colors = {
    info: "bg-blue-100 text-blue-700",
    success: "bg-green-100 text-green-700",
    error: "bg-red-100 text-red-700",
    warning: "bg-yellow-100 text-yellow-800",
  };

  return (
    <div className={`p-3 rounded mb-3 ${colors[type]} text-sm`}>{message}</div>
  );
};

export default Notification;
