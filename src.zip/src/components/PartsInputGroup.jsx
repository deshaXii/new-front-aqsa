import React from "react";
import VoiceInput from "./VoiceInput.jsx";

const PartsInputGroup = ({ parts, setParts }) => {
  const handlePartChange = (index, field, value) => {
    const updated = [...parts];
    updated[index][field] = value;
    setParts(updated);
  };

  const addPart = () => {
    setParts([...parts, { name: "", price: "", source: "" }]);
  };

  const removePart = (index) => {
    const updated = [...parts];
    updated.splice(index, 1);
    setParts(updated);
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded mb-4">
      <h3 className="font-bold mb-2">قطع الغيار</h3>
      {parts.map((part, index) => (
        <div
          key={index}
          className="mb-2 border p-2 rounded bg-white dark:bg-gray-700"
        >
          <div className="flex items-center gap-2 mb-2">
            <label className="w-20 font-medium">الاسم:</label>
            <input
              type="text"
              value={part.name}
              onChange={(e) => handlePartChange(index, "name", e.target.value)}
              placeholder="اسم القطعة"
              className="flex-1 p-1 rounded bg-gray-100 dark:bg-gray-600"
            />
            <VoiceInput
              onText={(text) => handlePartChange(index, "name", text)}
            />
          </div>

          <div className="flex items-center gap-2 mb-2">
            <label className="w-20 font-medium">السعر:</label>
            <input
              type="number"
              value={part.price}
              onChange={(e) => handlePartChange(index, "price", e.target.value)}
              placeholder="سعر القطعة"
              className="flex-1 p-1 rounded bg-gray-100 dark:bg-gray-600"
            />
            <VoiceInput
              onText={(text) => handlePartChange(index, "price", text)}
            />
          </div>

          <div className="flex items-center gap-2 mb-2">
            <label className="w-20 font-medium">المصدر:</label>
            <input
              type="text"
              value={part.source}
              onChange={(e) =>
                handlePartChange(index, "source", e.target.value)
              }
              placeholder="اسم المحل أو من المحل"
              className="flex-1 p-1 rounded bg-gray-100 dark:bg-gray-600"
            />
            <VoiceInput
              onText={(text) => handlePartChange(index, "source", text)}
            />
          </div>

          <button
            type="button"
            onClick={() => removePart(index)}
            className="text-red-500 text-sm"
          >
            حذف القطعة
          </button>
        </div>
      ))}

      <button
        type="button"
        onClick={addPart}
        className="bg-blue-500 text-white px-4 py-1 rounded text-sm mt-2"
      >
        إضافة قطعة غيار
      </button>
    </div>
  );
};

export default PartsInputGroup;
